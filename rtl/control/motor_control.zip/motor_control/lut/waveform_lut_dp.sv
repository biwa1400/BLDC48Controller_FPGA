// ============================================================================
// waveform_lut_dp.sv
//
// BLDC48Controller FPGA
//
// Dual-bank waveform LUT storage.
//
// Architecture:
//
//                    waveform_lut_dp
//
//        Write port                    Read port
//   (ARM / DMA side)              (calculation side)
//          |                              |
//          v                              v
//     +----------+                   +----------+
//     | Bank A   |------------------>| bank_a_q |
//     | 4096x13  |                   +----------+
//     +----------+                         |
//                                          |
//                                          +----+
//                                               |
//                                               +--> rd_data
//                                               |
//                                          +----+
//                                          |
//     +----------+                   +----------+
//     | Bank B   |------------------>| bank_b_q |
//     | 4096x13  |                   +----------+
//     +----------+
//
// The read bank selection is captured in rd_bank_q when rd_en is asserted.
//
// Bank roles:
//
//   active_bank
//       - Defines which bank is currently active at the system level.
//       - Used by the write port for hardware write protection.
//       - ARM / DMA writes to this bank are rejected.
//
//   rd_bank
//       - Selects which bank is read by the calculation datapath.
//       - Intended to come from the phase-command batch snapshot.
//       - Remains stable for the complete 22-phase calculation batch.
//
// Separating active_bank from rd_bank guarantees that one calculation batch
// can continue reading the exact bank captured at batch start.
//
// Responsibilities:
//   - Store two independent 4096 x 13 LUT banks.
//   - Perform synchronous writes.
//   - Perform synchronous reads.
//   - Reject writes to the currently active bank.
//   - Read from the explicitly selected calculation bank.
//
// NOT responsibilities:
//   - Commit protocol.
//   - Pending bank switch.
//   - Batch-boundary detection.
//   - Batch snapshot generation.
//   - Commit acknowledgement.
//
// Those policies belong to lut_bank_control.sv and phase_command_calc.sv.
//
// NOTE ABOUT "always":
//
// The RAM processes intentionally use ordinary clocked "always" rather
// than "always_ff".
//
// This allows the verification environment to preload the RAM using $readmemh
// through hierarchical access without violating the SystemVerilog always_ff
// single-procedural-driver rule.
//
// This does not change the synthesized sequential behavior of the RAM.
//
// ============================================================================

module waveform_lut_dp (

    input  logic        clk_50MHz,
    input  logic        rst_n,

    // ------------------------------------------------------------------------
    // Current system-level active bank
    //
    // 0 = Bank A active
    // 1 = Bank B active
    //
    // Used only for write protection.
    // ------------------------------------------------------------------------

    input  logic        active_bank,

    // ------------------------------------------------------------------------
    // ARM / DMA write port
    // ------------------------------------------------------------------------

    input  logic        wr_en,
    input  logic        wr_bank,
    input  logic [11:0] wr_addr,
    input  logic [12:0] wr_data,

    // ------------------------------------------------------------------------
    // Calculation read port
    //
    // rd_bank is intentionally independent from active_bank.
    // ------------------------------------------------------------------------

    input  logic        rd_bank,
    input  logic        rd_en,
    input  logic [11:0] rd_addr,
    output logic [12:0] rd_data

);


    // ========================================================================
    // LUT storage
    // ========================================================================

    logic [12:0] bank_a [0:4095];
    logic [12:0] bank_b [0:4095];


    // ========================================================================
    // RAM read outputs
    // ========================================================================

    logic [12:0] bank_a_q;
    logic [12:0] bank_b_q;


    // ========================================================================
    // Read-bank snapshot
    // ========================================================================

    logic rd_bank_q;


    // ========================================================================
    // Independent write enables
    // ========================================================================
    //
    // Bank A may only be written when Bank B is currently active.
    //
    // Bank B may only be written when Bank A is currently active.
    //
    // Equivalent to:
    //
    //     wr_en && (wr_bank != active_bank)
    //
    // ========================================================================

    wire wr_en_a;
    wire wr_en_b;

    assign wr_en_a =
        wr_en &&
        (wr_bank == 1'b0) &&
        (active_bank == 1'b1);

    assign wr_en_b =
        wr_en &&
        (wr_bank == 1'b1) &&
        (active_bank == 1'b0);


    // ========================================================================
    // Bank A RAM
    // ========================================================================
    //
    // Independent synchronous write and synchronous read.
    //
    // ========================================================================

    always @(posedge clk_50MHz) begin

        if (wr_en_a) begin

            bank_a[wr_addr] <=
                wr_data;

        end

        if (rd_en) begin

            bank_a_q <=
                bank_a[rd_addr];

        end

    end


    // ========================================================================
    // Bank B RAM
    // ========================================================================
    //
    // Independent synchronous write and synchronous read.
    //
    // ========================================================================

    always @(posedge clk_50MHz) begin

        if (wr_en_b) begin

            bank_b[wr_addr] <=
                wr_data;

        end

        if (rd_en) begin

            bank_b_q <=
                bank_b[rd_addr];

        end

    end


    // ========================================================================
    // Read-bank snapshot
    // ========================================================================
    //
    // Capture the requested bank together with the synchronous RAM read.
    //
    // This prevents a later change of rd_bank from changing the meaning of
    // the RAM data already returned by the read operation.
    //
    // ========================================================================

    always_ff @(posedge clk_50MHz) begin

        if (!rst_n) begin

            rd_bank_q <=
                1'b0;

        end
        else if (rd_en) begin

            rd_bank_q <=
                rd_bank;

        end

    end


    // ========================================================================
    // Read output selection
    // ========================================================================
    //
    // bank_a_q and bank_b_q are the registered synchronous outputs of the
    // two RAM banks.
    //
    // No additional output register is inserted here.
    //
    // Therefore this mux does NOT add another clock cycle to the RAM read.
    //
    // ========================================================================

    always_comb begin

        if (!rst_n) begin

            rd_data =
                13'd0;

        end
        else begin

            if (rd_bank_q == 1'b0) begin

                rd_data =
                    bank_a_q;

            end
            else begin

                rd_data =
                    bank_b_q;

            end

        end

    end


endmodule