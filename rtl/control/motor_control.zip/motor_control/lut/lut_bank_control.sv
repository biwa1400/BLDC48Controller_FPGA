// ============================================================================
// lut_bank_control.sv
//
// BLDC48Controller FPGA
// LUT A/B bank control.
//
// Responsibilities:
//   - Maintain current active LUT bank.
//   - Latch LUT commit requests.
//   - Delay bank switching until a safe calculation boundary.
//   - Toggle active bank atomically.
//   - Generate commit acknowledgement.
//
// Bank convention:
//   0 = Bank A
//   1 = Bank B
//
// Commit protocol:
//
//   lut_commit_req
//          |
//          v
//   commit_pending = 1
//          |
//          | wait
//          v
//      safe_switch
//          |
//          v
//   active_bank toggles
//          |
//          v
//   lut_commit_ack = 1
//          |
//          | request released
//          v
//   lut_commit_ack = 0
//
// Important:
//   The external side does NOT directly select the new active bank.
//   A successful commit always switches to the other bank.
//
// ============================================================================

module lut_bank_control (
    input  logic clk_50MHz,
    input  logic rst_n,

    // ------------------------------------------------------------------------
    // Commit request
    // ------------------------------------------------------------------------

    input  logic lut_commit_req,

    // ------------------------------------------------------------------------
    // Safe switching point
    //
    // Must only be asserted when:
    //
    //   - no calculation batch is currently using the LUT, and
    //   - the next batch has not yet taken its bank snapshot.
    //
    // ------------------------------------------------------------------------

    input  logic safe_switch,

    // ------------------------------------------------------------------------
    // Status
    // ------------------------------------------------------------------------

    output logic active_bank,
    output logic commit_pending,
    output logic lut_commit_ack
);


    // ========================================================================
    // Bank / commit state machine
    // ========================================================================

    always_ff @(posedge clk_50MHz) begin

        if (!rst_n) begin

            active_bank     <= 1'b0;
            commit_pending  <= 1'b0;
            lut_commit_ack  <= 1'b0;

        end
        else begin

            // ---------------------------------------------------------------
            // ACK handshake completion
            // ---------------------------------------------------------------
            //
            // Once ACK has been generated, it remains high until the
            // requester releases lut_commit_req.
            //
            // This makes the interface suitable for a persistent control
            // register on the future lightweight HPS-to-FPGA bridge.
            // ---------------------------------------------------------------

            if (lut_commit_ack) begin

                if (!lut_commit_req) begin

                    lut_commit_ack <= 1'b0;

                end

            end
            else begin

                // -----------------------------------------------------------
                // Capture a new commit request.
                // -----------------------------------------------------------

                if (lut_commit_req) begin

                    commit_pending <= 1'b1;

                end


                // -----------------------------------------------------------
                // Execute pending commit only at a safe boundary.
                //
                // The lut_commit_req term allows the first cycle of a new
                // request to commit immediately when the core is already at
                // a safe boundary.
                // -----------------------------------------------------------

                if (
                    safe_switch &&
                    (commit_pending || lut_commit_req)
                ) begin

                    active_bank    <= ~active_bank;
                    commit_pending <= 1'b0;
                    lut_commit_ack <= 1'b1;

                end

            end

        end

    end

endmodule