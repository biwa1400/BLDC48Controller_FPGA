// ============================================================================
// motor_lut_avalon_slave.sv
//
// BLDC48Controller FPGA
//
// Avalon-MM slave adapter for the motor-control dual-bank waveform LUT.
//
// Address map (word addressed):
//
//   0x0000 : CONTROL
//            bit 0 = LUT commit request
//
//   0x0001 : STATUS
//            bit 0 = active bank
//            bit 1 = commit acknowledge
//
//   0x1000 - 0x1FFF : LUT[0] - LUT[4095]
//
// LUT writes are always directed to the inactive bank:
//
//   lut_wr_bank = ~lut_active_bank
//
// The motor_drive_core performs an additional active-bank write-protection
// check inside waveform_lut_dp.
// ============================================================================

module motor_lut_avalon_slave (
    input  logic        clk,
    input  logic        reset_n,

    // Avalon-MM slave interface
    input  logic [12:0] avs_address,
    input  logic        avs_write,
    input  logic        avs_read,
    input  logic [31:0] avs_writedata,
    output logic [31:0] avs_readdata,

    // Motor-control LUT write interface
    output logic        lut_wr_en,
    output logic        lut_wr_bank,
    output logic [11:0] lut_wr_addr,
    output logic [12:0] lut_wr_data,

    // Motor-control LUT commit interface
    output logic        lut_commit_req,
    input  logic        lut_active_bank,
    input  logic        lut_commit_ack
);

    localparam logic [12:0] ADDR_CONTROL  = 13'h0000;
    localparam logic [12:0] ADDR_STATUS   = 13'h0001;
    localparam logic [12:0] ADDR_LUT_BASE = 13'h1000;

    logic lut_address_selected;

    assign lut_address_selected = (avs_address >= ADDR_LUT_BASE);

    assign lut_wr_en   = avs_write && lut_address_selected;
    assign lut_wr_bank = ~lut_active_bank;
    assign lut_wr_addr = avs_address[11:0];
    assign lut_wr_data = avs_writedata[12:0];

    always_ff @(posedge clk) begin
        if (!reset_n) begin
            lut_commit_req <= 1'b0;
        end
        else begin
            if (avs_write && (avs_address == ADDR_CONTROL))
                lut_commit_req <= avs_writedata[0];
            else if (lut_commit_ack)
                lut_commit_req <= 1'b0;
        end
    end

    always_comb begin
        avs_readdata = 32'd0;

        if (avs_read) begin
            case (avs_address)
                ADDR_CONTROL: begin
                    avs_readdata[0] = lut_commit_req;
                end

                ADDR_STATUS: begin
                    avs_readdata[0] = lut_active_bank;
                    avs_readdata[1] = lut_commit_ack;
                end

                default: begin
                    avs_readdata = 32'd0;
                end
            endcase
        end
    end

endmodule